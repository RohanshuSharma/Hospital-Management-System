<?php
include('config.php');
session_start();


?>
<!DOCTYPE html>
<html>
    <head>
        <title>Landmark's Kitchen</title>
        <link rel = "stylesheet" type = "text/css" href = "css\style3.css" />
        <script type = "text/javascript" 
        src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
     </script>
     <script type="text/javascript">
     
     function disp(){
        var node=document.createElement("th");
        var tnode=document.createTextNode(document.getElementById("nn").innerHTML);
        node.appendChild(tnode);
        document.getElementById("do").appendChild(node);
        var na=document.createElement("td");
        var tna=document.createTextNode(document.getElementById("qty").value);
        na.appendChild(tna);
        document.getElementById("qtyy").appendChild(na);
        // var a=document.getElementById("dish_r").innerHTML;
        // document.getElementById("pre").innerHTML=a;
        // flag=true;
        // var b=document.getElementById("qty").value;
        // document.getElementById("qtyy").innerHTML=b;

     }
     function disp1(){
        var node=document.createElement("p");
        var tnode=document.createTextNode(document.getElementById("nn1").innerHTML);
        node.appendChild(tnode);
        document.getElementById("det_o").appendChild(node);
        
        // var a=document.getElementById("dish_r").innerHTML;
        // document.getElementById("pre").innerHTML=a;
        // flag=true;
        // var b=document.getElementById("qty").value;
        // document.getElementById("qtyy").innerHTML=b;

     }
     function disp2(){
        var node=document.createElement("p");
        var tnode=document.createTextNode(document.getElementById("nn2").innerHTML);
        node.appendChild(tnode);
        document.getElementById("det_o").appendChild(node);

        // var a=document.getElementById("dish_r").innerHTML;
        // document.getElementById("pre").innerHTML=a;
        // flag=true;
        // var b=document.getElementById("qty").value;
        // document.getElementById("qtyy").innerHTML=b;

     }




     </script>
        <script type="text/javascript" language="javascript">
            jQuery(function(){
    var j = jQuery;
    var addInput = '#qty'; 
    var n = 0; 
    
    
    j(addInput).val(n);

    
    j('.plus').on('click', function(){
        j(addInput).val(++n);
    })

    j('.min').on('click', function(){
        
        if (n >= 1) {
        j(addInput).val(--n);
        } else {
        
        }
    });
    });
</script>
<script type="text/javascript" language="javascript">
    jQuery(function(){
var j = jQuery;
var addInput1 = '#qty1'; 
var n = 0; 


j(addInput1).val(n);


j('.plus1').on('click', function(){
j(addInput1).val(++n);
})

j('.min1').on('click', function(){

if (n >= 1) {
j(addInput1).val(--n);
} else {

}
});
});
</script>
<script type="text/javascript" language="javascript">
    jQuery(function(){
var j = jQuery;
var addInput2 = '#qty2'; 
var n = 0; 


j(addInput2).val(n);


j('.plus2').on('click', function(){
j(addInput2).val(++n);
})

j('.min2').on('click', function(){

if (n >= 1) {
j(addInput2).val(--n);
} else {

}
});
});
</script>
        
    </head>
    <body>
            <div class="header">
                    <div class="hbar">
                        <img id="acc" src="img/account.svg">
                    </div>
                    <table cellspacing="10">
                        <tr>
                            <th id="rest_im"><div class="res1">
                                    <img id="ht1" src="img/food1.PNG">
                                </div></th>
                            <th><p id="rest_name">Landmark's Kitchen</p><br>
                                <label id="rest_det">North Indian, Chinese, Continental, Beverages</label>
                            </th>
                        </tr>
                    </table>
                    
                    
                </div>
                
                <div class="menu">
                    <div class="menu_1">
                        <p id="hm">Exclusive combos</p>
                        <table cellspacing="0">
                            <tr>
                                <th><p id="dish_r"><img id="veg" src=img/veg.png><label id="nn">Landmark's Handi Sabji + Roti (2 Pcs.)</label>&nbsp;</p></th>
                                <th id="addc"><span onclick="disp()" class="plus button" id="plusbt">
                                        +
                                        </span>
                                        <input type="text" name="qty" id="qty" maxlength="12"/>
                                        <span class="min button">
                                        -</span></th>
                                
                            </tr>
                            <tr>
                                <td id="prc"><h4 id="d_prc">&emsp;&emsp;₹<label id="price">500</label></h4></td>
                            </tr>
                            <tr>
                                <td><hr width=180%></hr></td>
                            </tr>
                        </table>
                        
                        <table cellspacing="0">
                            <tr>
                                <th><p id="dish_r"><img id="veg" src=img/veg.png><label id="nn1"> Schezwan Noodles + Cottage Cheese Chilly Dry</label></p></th>
                                <th id="addc"><span onclick="disp1()" class="plus1 button">
                                        +
                                        </span>
                                        <input type="text" name="qty" id="qty1" maxlength="12"/>
                                        <span class="min1 button">
                                        -</span></th>
                                
                            </tr>
                            <tr>
                                <td id="prc"><h4 id="d_prc">&emsp;₹<label id="price">400</label></h4></td>
                            </tr>
                            <tr>
                                <td><hr width=150%></hr></td>
                            </tr>
                        </table>
                        <table cellspacing="0">
                                <tr>
                                    <th><p id="dish_r"><img id="veg" src=img/nonveg.png> <label id="nn2">Butter Chicken Biryani</label></p></th>
                                    <th id="addc"><span onclick="disp2()" class="plus2 button">
                                            +
                                            </span>
                                            <input type="text" name="qty" id="qty2" maxlength="12"/>
                                            <span class="min2 button">
                                            -</span></th>
                                    
                                </tr>
                                <tr>
                                    <td id="prc"><h4 id="d_prc">&emsp;₹<label id="price">240</label></h4></td>
                                </tr>
                                <tr>
                                    <td><hr width=300%></hr></td>
                                </tr>
                            </table>
                            
                        
                    </div>
                   
                    
                    </div>
                    <div class="cart">
                        <div class="cart_details">
                            <p id="c_head">Cart</p>
                            <div id="det_o">
                                <label id="box1">Table No.</label> <input type="number" name="tabname" id="box"><label id="box2" name="accname">Mr/Mrs. XYZ</label>
                                <table id="od">
                                    <tr id="do">

                                     </tr>   
                                     <tr id="qtyy">
                                     </tr>
                                </table>

                            </div>
                        </div>
                    </div>
                    
                    

               
    </body>
    </html>
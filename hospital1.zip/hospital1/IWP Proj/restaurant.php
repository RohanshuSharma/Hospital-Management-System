<?php
include('config.php');
session_start();


?>
<!DOCTYPE html>
<html>
    <head>
        <title>Restaurants</title>
        <script type = "text/javascript" 
         src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
        <link rel = "stylesheet" type = "text/css" href = "css\style2.css" />
        <script type = "text/javascript" language = "javascript">
            $(document).ready(function() {
   
               $('res1').hover(
                   
                  function () {
                     $(this).css({"border":"1px solid black"});
                  }, 
                   
                  function () {
                     $(this).css({"border":"0px solid black"});
                  }
               );
                   
            });
         </script>
         
        
    </head>
    <body>
            <div class="header">
                    <div class="hbar">
                        <img id="acc" src="img/account.svg">
                    </div>
                    
                </div>
                <div  class="bar">
                        <input type="text" id="search" placeholder="Search By Name/ID" name="resname" required><button id="btn"><img src="img/search.svg" id="s1" alt="glass">Search</button>
                    </div>
                <div class="rest">
                    <table cellspacing="10">
                        <tr>
                            <th class="ho" onclick="location.href='r.html'"><div class="res1">
                                    <img id="im1" src="img/food1.png"><br>
                                    <p>Landmark's Kitchen</p>
                                </div></th>
                     <th class="ho"><div class="res1">
                            <img id="im1" src="img/food2.png"><br>
                            <p>Monroe</p></div></th>
                            <th class="ho"><div class="res1">
                                    <img id="im1" src="img/food3.png"><br>
                                    <p>Flo Cafe</p></div></th>
                            </tr>
                            <tr>
                                <td class="ho"><div class="res1">
                                        <img id="im1" src="img/food4.png"><br>
                                        <p>Maharaja Bhog</p></div></td>
                                <td class="ho"><div class="res1">
                                        <img id="im1" src="img/food5.png"><br>
                                        <p>Folk Tale</p></div></td>
                                        <td class="ho"><div class="res1">
                                                <img id="im1" src="img/food6.png"><br>
                                                <p>Foodland</p></div></td>
                            </tr>
                </table>
                    
                </div>
    </body>
    </html>
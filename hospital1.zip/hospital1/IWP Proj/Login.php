<?php
include('config.php');

if(isset($_POST['log1'])){
    $username=$_POST['mail'];
    $password=$_POST['pwd'];

    $q="select * from userlogin where UserId='$username' and password='$password'";
    $query=mysqli_query($q,$con);
    $num=mysqli_fetch_array($query);
    if($num>0){
        $extra="restaurant.php";
        $_SESSION['login']=$_POST['username'];
        $_SESSION['id']=$num['id'];
        $host=$_SERVER['HTTP_HOST'];
        $uip=$_SERVER['REMOTE_ADDR'];
        header("location:http://$host$uri/$extra");
        exit();
    }
    else
    {

        $_SESSION['errmsg']="Invalid username or password";
    }

}


?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login/SignUp</title>
        <link rel = "stylesheet" type = "text/css" href = "css\style1.css" />
        
    </head>
    <body>
            <div class="header">
                    <div class="hbar">
                        <img id="acc" src="img/account.svg">
                    </div>
                    
                </div>

                <div class="log">
                    <h1 id="fol">Customer Log In</h1>
                    <h3 id="fo1">Welcome back! Log In here.</h3>
                    <form method="post">
                        
                        <input type="email" name="mail" placeholder="Email" id="em"><br><br>
                        <input type="password" name="pwd" placeholder="Password" id="em1"><br><br><br><br>
                        <button type="submit" id="log" name="log1">Login</button>                    

                    
                        
                    </form>
                </div>

    </body>


</html>